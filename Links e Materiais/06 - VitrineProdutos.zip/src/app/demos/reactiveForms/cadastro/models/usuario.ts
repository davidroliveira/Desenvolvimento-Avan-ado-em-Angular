export interface Usuario {
    id: string;
    nome: string;
    CPF: string;
    email: string;
    senha: string;
    senhaConfirmacao: string;
}