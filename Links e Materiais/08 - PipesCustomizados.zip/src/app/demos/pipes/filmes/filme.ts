export interface Filme {
    nome: string,
    dataLancamento: Date
    valor: number,
    imagem: string,
    tamanho: string
  }