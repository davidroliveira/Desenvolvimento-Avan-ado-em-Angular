export interface Task {
  id: number;
  nome: string;
  iniciado: boolean;
  finalizado: boolean;
}
